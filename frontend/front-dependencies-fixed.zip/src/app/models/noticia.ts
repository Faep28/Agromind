export interface Noticia {
}

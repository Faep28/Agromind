export interface Notificacion {
}

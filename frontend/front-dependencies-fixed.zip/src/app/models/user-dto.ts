export interface UserDto {
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-cultivos',
  standalone: false,
  templateUrl: './cultivos.html',
  styleUrl: './cultivos.css',
})
export class Cultivos {

}

export interface Servicio {
}

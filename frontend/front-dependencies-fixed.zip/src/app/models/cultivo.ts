export interface Cultivo {
}

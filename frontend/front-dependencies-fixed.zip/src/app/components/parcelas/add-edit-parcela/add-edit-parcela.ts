import { Component } from '@angular/core';

@Component({
  selector: 'app-add-edit-parcela',
  standalone: false,
  templateUrl: './add-edit-parcela.html',
  styleUrl: './add-edit-parcela.css',
})
export class AddEditParcela {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-registro-cultivo',
  standalone: false,
  templateUrl: './registro-cultivo.html',
  styleUrl: './registro-cultivo.css',
})
export class RegistroCultivo {

}

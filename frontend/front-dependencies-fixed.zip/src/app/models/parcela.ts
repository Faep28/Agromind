export interface Parcela {
}

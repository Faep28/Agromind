import { Component } from '@angular/core';

@Component({
  selector: 'app-parcela-list',
  standalone: false,
  templateUrl: './parcela-list.html',
  styleUrl: './parcela-list.css',
})
export class ParcelaList {

}

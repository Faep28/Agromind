export interface Cliente {
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-registro-noticias',
  standalone: false,
  templateUrl: './registro-noticias.html',
  styleUrl: './registro-noticias.css',
})
export class RegistroNoticias {

}

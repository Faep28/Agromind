export interface CultivoFertilizante {
}

export interface TokenDto {
}

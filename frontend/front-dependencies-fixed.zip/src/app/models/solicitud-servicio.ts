export interface SolicitudServicio {
}

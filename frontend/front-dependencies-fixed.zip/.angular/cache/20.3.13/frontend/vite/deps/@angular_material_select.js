import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-DTS23SUH.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-BKLJ5N4Y.js";
import "./chunk-Z7DKZ7MB.js";
import "./chunk-AXY65ADK.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-WQXXM5BO.js";
import "./chunk-KPTEEAQY.js";
import "./chunk-HDE7SAT4.js";
import "./chunk-64R233DN.js";
import "./chunk-YWVNW5KE.js";
import "./chunk-6IOBH7GY.js";
import "./chunk-2W3WA55Y.js";
import "./chunk-JQHOGXJF.js";
import "./chunk-LHDXZJBQ.js";
import "./chunk-AXX6UZ5E.js";
import "./chunk-K5WRV2ZI.js";
import "./chunk-HBF2LOUD.js";
import "./chunk-O3CDY47V.js";
import "./chunk-GWFLKVBH.js";
import "./chunk-VENV3F3G.js";
import "./chunk-OWWQDQTX.js";
import "./chunk-5EG33CFQ.js";
import "./chunk-NLCZBGAC.js";
import "./chunk-HJUFWOXB.js";
import "./chunk-BXX2HSGB.js";
import "./chunk-TOVMTX4B.js";
import "./chunk-P5CTDYE3.js";
import "./chunk-TQL27XZ3.js";
import "./chunk-CYIUJTKM.js";
import "./chunk-7ZNSXDVY.js";
import "./chunk-TXDUYLVM.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [
      {
        type: 0,
        name: "void",
        styles: {
          type: 6,
          styles: { opacity: 0, transform: "scale(1, 0.8)" },
          offset: null
        }
      },
      {
        type: 1,
        expr: "void => showing",
        animation: {
          type: 4,
          styles: {
            type: 6,
            styles: { opacity: 1, transform: "scale(1, 1)" },
            offset: null
          },
          timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
        },
        options: null
      },
      {
        type: 1,
        expr: "* => void",
        animation: {
          type: 4,
          styles: { type: 6, styles: { opacity: 0 }, offset: null },
          timings: "100ms linear"
        },
        options: null
      }
    ],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map

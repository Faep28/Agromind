export interface Fertilizante {
}
